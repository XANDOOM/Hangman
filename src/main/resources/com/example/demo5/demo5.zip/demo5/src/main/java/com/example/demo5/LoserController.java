package com.example.demo5;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class LoserController {

    @FXML
    private Button revealButton;
    public void onRestartButton(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        HelloApplication.game(stage);
    }

    public void onExitButton(ActionEvent event) {
        Platform.exit();
    }


    public void onRevealButton(ActionEvent event) {
        revealButton.setText(HelloController.show_ans());
    }
}
